import * as actions from './actions';
import reducer from './reducer';
import view from './view';

export { actions, reducer, view };
