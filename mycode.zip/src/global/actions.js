import { COLLAPSED } from './actionTypes';

export const updateLayoutCollapsed = payload => ({
    type: COLLAPSED,
    payload
});

