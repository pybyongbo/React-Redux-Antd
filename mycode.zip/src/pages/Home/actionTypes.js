export const FETCH_LIST_BEGIN = 'FETCH/LIST_BEGIN';
export const GET_POST_LIST = 'POST/LIST';
export const FETCH_LIST_ERROR = 'FETCH/LIST_ERROR';
export const GET_POST_INFO = 'POST/INFO';
