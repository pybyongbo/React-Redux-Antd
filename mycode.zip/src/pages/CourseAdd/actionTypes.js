// 课程类别
export const GET_COURSE_FIELD_LIST = 'get_course_field_list';

