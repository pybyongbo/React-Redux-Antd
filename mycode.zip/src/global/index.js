import * as actions from './actions';
import reducer from './reducer';

export { actions, reducer };
