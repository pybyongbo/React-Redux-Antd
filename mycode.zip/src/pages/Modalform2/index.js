import view from './view';

export { view };
