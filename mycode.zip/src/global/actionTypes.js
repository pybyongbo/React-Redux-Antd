export const COLLAPSED = 'COLLAPSED';
