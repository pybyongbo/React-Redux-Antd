// 课程分类
export const GET_COURSE_CATE_LIST = 'get_course_cate_list';

// export const DELETE_COURSE_CATE = 'delete_course_cate';
