// tab选项卡数据
export const GET_COURSE_FIELD_LIST = 'get_course_field_list';

// 列表是否显示加载中loading动画
export const COURSE_LIST_IS_LOADING = 'course_list_is_loading';

// 课程分类数据
export const GET_COURSE_LIST = 'get_course_list';

// 切换tab选项卡
export const CHANGE_COURSE_FIELD = 'change_course_field';

// 切换列表展示样式
export const CHANGE_SHOW_TYPE = 'change_show_type';
